package com.satnamsinghmaggo.crudmate

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.firestore.auth.User

class UserDetails : AppCompatActivity() {
    private lateinit var dbHelper: UserDatabaseHelper
    private var userId: Int = -1

    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var etCity: EditText
    private lateinit var etState: EditText
    private lateinit var etPhone: EditText
    private lateinit var etAddress: EditText
    private lateinit var etOccupation: EditText
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_user_details)

        dbHelper = UserDatabaseHelper(this)
        userId = intent.getIntExtra("userId", -1)

        etName = findViewById(R.id.etName)
        etAge = findViewById(R.id.etAge)
        etCity = findViewById(R.id.etCity)
        etState = findViewById(R.id.etState)
        etPhone = findViewById(R.id.etPhone)
        etAddress = findViewById(R.id.etAddress)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnDelete = findViewById(R.id.btnDelete)

        if (userId != -1) {
            val user = dbHelper.getUserById(userId)
            user?.let {
                etName.setText(it.name)
                etAge.setText(it.age.toString())
                etCity.setText(it.city)
                etState.setText(it.state)
                etPhone.setText(it.phone)
                etAddress.setText(it.address)
                etOccupation.setText(it.occupation)
            }
        }

        btnUpdate.setOnClickListener {
            val updatedUser = UserData(
                id = userId,
                name = etName.text.toString(),
                age = etAge.text.toString().toInt(),
                city = etCity.text.toString(),
                state = etState.text.toString(),
                phone = etPhone.text.toString(),
                address = etAddress.text.toString(),

            )
            dbHelper.updateUser(updatedUser)
            Toast.makeText(this, "User updated", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnDelete.setOnClickListener {
            dbHelper.deleteUser(userId)
            Toast.makeText(this, "User deleted", Toast.LENGTH_SHORT).show()
            finish()
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}