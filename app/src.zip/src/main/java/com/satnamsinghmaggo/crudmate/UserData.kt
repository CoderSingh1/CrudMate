package com.satnamsinghmaggo.crudmate

data class UserData(
        var id: Int = 0,
        var name: String,
        var age: Int,
        var city: String,
        var state: String,
        var phone: String,
        var address: String,
    )

