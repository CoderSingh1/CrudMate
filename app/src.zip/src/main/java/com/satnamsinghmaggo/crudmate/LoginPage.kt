package com.satnamsinghmaggo.crudmate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.jar.Attributes.Name

class LoginPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // enableEdgeToEdge()
        setContentView(R.layout.activity_login_page)

        val textview = findViewById<TextView>(R.id.tvSignup)
        val editText = findViewById<TextView>(R.id.emailET)
        val editText2 = findViewById<TextView>(R.id.passwordET)
        val loginButton = findViewById<Button>(R.id.btnLogin)


        textview.setOnClickListener {
            val intent = Intent(this, SignUpPage::class.java)
            startActivity(intent)
            finish()
        }

        val sharedPref = getSharedPreferences("userSession", MODE_PRIVATE)
        val editor = sharedPref.edit()

        val enteredName = editText.text.toString().trim()
        val enteredUserid = editText2.text.toString().trim()

        val savedEmail = sharedPref.getString("email", null)
        val savedPassword = sharedPref.getString("password", null)

        if (enteredName.isEmpty() || enteredUserid.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
        } else {
            if (savedEmail == null || savedPassword == null) {
                editor.putString("Name", enteredName)
                editor.putString("UserId", enteredUserid)
                editor.putBoolean("isLoggedIn", true)
                editor.apply()

                Toast.makeText(this, "Signed up successfully!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                // 🔐 Check if credentials match
                if (enteredName == savedEmail && enteredUserid == savedPassword) {
                    editor.putBoolean("isLoggedIn", true)
                    editor.apply()

                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                    loginButton.setOnClickListener {
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }

                } else {
                    Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
                }
            }
        }






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}